function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Yda3E6wdW2":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

